class Square extends Shape{
    public void getNumSides(){
        numSides=4;
    }
}
class Triangle extends Shape{
    public void getNumSides(){
        numSides=3;
    }
}
class Pentagon extends Shape{
    public void getNumSides(){
        numSides=5;
    }
}
